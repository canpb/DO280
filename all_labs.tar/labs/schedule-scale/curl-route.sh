for i in {1..10}; 
do
       	curl http://scaling-schedule-scale.apps.ocp-jppjvorndzppqro200626.do280.rht-na.nextcle.com; 
done;

